package com.example.LibrarySimpleApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibrarySimpleAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
