package com.example.LibrarySimpleApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibrarySimpleAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibrarySimpleAppApplication.class, args);
	}

}
