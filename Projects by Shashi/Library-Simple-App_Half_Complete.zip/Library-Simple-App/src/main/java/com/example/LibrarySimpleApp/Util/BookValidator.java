package com.example.LibrarySimpleApp.Util;

import com.example.LibrarySimpleApp.dto.Book;

public class BookValidator {

    public boolean isValid(Book book){

        if(book.getName()=="" && book.getName().equals(null))
            return false;
        return true;
    }
}
