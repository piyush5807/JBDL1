package com.example.LibrarySimpleApp.Resources;

import com.example.LibrarySimpleApp.dto.Book;
import com.example.LibrarySimpleApp.dto.BookRepository;
import com.example.LibrarySimpleApp.dto.User;
import com.example.LibrarySimpleApp.dto.UserRepository;
import com.example.LibrarySimpleApp.exception.UserNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

@RestController
public class UserResource {
    @Autowired
    private UserRepository repository;
    // Find
    @GetMapping("/users")
    List<User> findAll() {
        return repository.findAll();
    }

    @PostMapping("/users")
    //return 201 instead of 200
    @ResponseStatus(HttpStatus.CREATED)
    User newUser(@RequestBody User newUser) {
        return repository.save(newUser);
    }

    // Find
    @GetMapping("/users/{id}")
    User findOne(@PathVariable int id) {
       // Optional<User> user = repository.findById(id);
        return repository.findById(id)
          .orElseThrow(() -> new UserNotFoundException(id));
    }

}
