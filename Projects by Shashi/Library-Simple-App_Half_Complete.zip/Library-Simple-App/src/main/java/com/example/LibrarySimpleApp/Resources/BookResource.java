package com.example.LibrarySimpleApp.Resources;

import com.example.LibrarySimpleApp.Util.BookValidator;
import com.example.LibrarySimpleApp.dto.Book;
import com.example.LibrarySimpleApp.dto.BookRepository;
import com.example.LibrarySimpleApp.exception.BookNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;

@RestController
public class BookResource {
    @Autowired
    private BookRepository repository;

    BookValidator validator = new BookValidator();

    // Find
    @GetMapping("/books")
    List<Book> findAll() {
        List<Book> list = new ArrayList<Book>();
        list = repository.findAll();
        /*
        try {
            list = repository.findAll();
            if (list.size() == 0) {
                throw new BookNotFoundException(5);
            }
        }
    catch(BookNotFoundException exc)
    {
        System.out.println(exc);
        throw new ResponseStatusException(
                HttpStatus.NOT_FOUND, "No Book Found", exc);
    }

         */
return list;
}

    @PostMapping("/books")
    //return 201 instead of 200
    @ResponseStatus(HttpStatus.CREATED)
    Book newBook(@RequestBody Book newBook) {

      //  if(validator.isValid(newBook))
        return repository.save(newBook);
      //  else
    }
}
