package com.example.Actuator_new;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActuatorNewApplicationTests {

	@Test
	void contextLoads() {
	}

}
