package com.example.Actuator_new;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActuatorNewApplication {

	public static void main(String[] args) {
		SpringApplication.run(ActuatorNewApplication.class, args);
	}

}
