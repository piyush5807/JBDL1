package com.example.Spring3.dto;

public class GitHubRepositoriesResponse extends GitHubResponse<Repository> {
}
