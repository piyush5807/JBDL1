package com.example.spring_boot_demo_api_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDemoApi1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
