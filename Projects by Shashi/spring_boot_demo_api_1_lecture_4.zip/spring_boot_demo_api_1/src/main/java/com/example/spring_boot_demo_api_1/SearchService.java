package com.example.spring_boot_demo_api_1;

import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class SearchService {
    public List<String> searchAWord( String q){
        //
        ArrayList<String> list = new ArrayList<String>();
        list.add("Sachin");
        list.add(" is");
        list.add("A great");
        list.add("batsman");
        HashMap<String,ArrayList<String>> dataStore =
        new HashMap<String,ArrayList<String>>();
        dataStore.put("Sachin", list);
        //

       return dataStore.get(q);
    }
}
