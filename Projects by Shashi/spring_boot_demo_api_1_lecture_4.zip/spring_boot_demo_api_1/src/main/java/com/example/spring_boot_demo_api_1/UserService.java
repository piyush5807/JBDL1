package com.example.spring_boot_demo_api_1;

import java.util.ArrayList;

public class UserService {
    public User getAUser(String id) {

        UserDataStore dataStore = new UserDataStore();
        return dataStore.getAUser(id);
    }
}
