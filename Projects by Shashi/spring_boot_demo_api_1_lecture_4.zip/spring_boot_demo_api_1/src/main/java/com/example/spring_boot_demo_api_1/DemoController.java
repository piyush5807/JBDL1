package com.example.spring_boot_demo_api_1;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

import static org.springframework.web.bind.annotation.RequestMethod.GET;

@RestController
public class DemoController {

    @RequestMapping("/")
    public String index() {
        return "Greetings from Spring Boot!";
    }

    @RequestMapping("/str")
    public String fun2() {
        return "Java Backend";
    }

    @RequestMapping(value = "/getA", method = GET)
    public String getAString2() {
        return "Java Backend 2";
    }

    // http://localhost:8080/search?q=Sachin
    @RequestMapping(value = "/search", method = GET)
    public List<String> searchAWord(@RequestParam("q") String q){
       SearchService service = new SearchService();
       return service.searchAWord(q);
    }

    // https://api.github.com/users/shashipk

    @RequestMapping(value = "/users/{id}", method = GET)
    //@ResponseBody
    public User getAUser(@PathVariable("id") String id) {
        UserService service = new UserService();
        return service.getAUser(id);
    }

    @PostMapping(path = "/users", consumes = "application/json", produces = "application/json")
    public User addMember(@RequestBody User user) {
        System.out.println("Post call for User Creation");
        // addAUser --> insertAUser (data store)
        return user;
    }




}
