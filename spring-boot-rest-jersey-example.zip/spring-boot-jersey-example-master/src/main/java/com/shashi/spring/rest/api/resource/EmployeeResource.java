package com.shashi.spring.rest.api.resource;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import com.shashi.spring.rest.api.model.Employee;

@Path("/employeeResource")
public class EmployeeResource {

	@POST
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/save")
	public Employee saveEmployee(Employee employee) {

		System.out.println("saveEmployee");
		return employee;
	}
	
	@GET
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/getAllEmployees")
	public List<Employee> getAllEMployees(){
		List<Employee> list = new ArrayList<Employee>();
		Employee emp = new Employee();
		emp.setId(1);
		emp.setDept("abc");
		emp.setName("ramu");
		list.add(emp);
		return list;
	}
	
	@GET
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/getEmployee/{name}")
	public Employee getEmployeeByName(@PathParam("name") String name) {
		Employee emp = new Employee();
		emp.setId(1);
		emp.setDept("abc");
		emp.setName("ramu");
		return emp;
	}

}
