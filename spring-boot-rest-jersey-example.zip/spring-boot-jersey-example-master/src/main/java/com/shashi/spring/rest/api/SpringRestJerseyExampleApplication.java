package com.shashi.spring.rest.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestJerseyExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestJerseyExampleApplication.class, args);
	}

}
