# spring-boot-jersey-example
Develop Restful Webservices using Jax-Rs Jersey Implementation -Spring Boot
